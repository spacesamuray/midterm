﻿using midterm_api.Data;
using midterm_api.DTOs;
using midterm_api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace midterm_api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoreProductsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StoreProductsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetProducts()
        {
            var products = await _context.Products
                .Select(product => new ProductDto
                {
                    Name = product.Name,
                    Price = product.Price
                })
                .ToListAsync();

            return Ok(products);
        }

        [HttpPost]
        public async Task<ActionResult<ProductDto>> AddProduct([FromBody] ProductDto productDto)
        {
            if (string.IsNullOrWhiteSpace(productDto.Name))
            {
                return BadRequest("Product name is required.");
            }

            var product = new DbProduct
            {
                Name = productDto.Name,
                Price = productDto.Price
            };

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return Ok(new ProductDto
            {
                Name = product.Name,
                Price = product.Price
            });
        }
    }
}

