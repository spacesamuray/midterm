﻿using Microsoft.AspNetCore.Mvc;
using midterm_api.Interfaces;
using midterm_api.Models;

namespace midterm_api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        // Task 1: Save products to cache
        [HttpPost("cache")]
        public IActionResult SaveProductsToCache([FromBody] List<Product> products)
        {
            if (products == null || products.Count == 0)
            {
                return BadRequest("Product list cannot be empty.");
            }

            _productService.SaveProductsToCache(products);
            return Ok("Products saved to cache successfully.");
        }

        // Task 1: Get all products from cache
        [HttpGet("cache")]
        public IActionResult GetAllProductsFromCache()
        {
            var products = _productService.GetAllProductsFromCache();
            return Ok(products);
        }

        // Task 2: Pagination
        [HttpGet("paged")]
        public IActionResult GetProductsPaged([FromQuery] int pageIndex, [FromQuery] int pageSize)
        {
            if (pageIndex < 0 || pageSize <= 0)
            {
                return BadRequest("pageIndex must be >= 0 and pageSize must be > 0.");
            }

            var products = _productService.GetProductsPaged(pageIndex, pageSize);
            return Ok(products);
        }

        // Task 3: Filtering
        [HttpGet("filter")]
        public IActionResult FilterProducts([FromQuery] string category, [FromQuery] int minYear)
        {
            if (string.IsNullOrWhiteSpace(category))
            {
                return BadRequest("Category is required.");
            }

            var products = _productService.FilterProducts(category, minYear);
            return Ok(products);
        }
    }
}
