﻿using Microsoft.Extensions.Caching.Memory;
using midterm_api.Interfaces;
using midterm_api.Models;

namespace midterm_api.Services
{
    public class ProductsService : IProductService
    {
        private readonly IMemoryCache _memoryCache;
        private const string CacheKey = "products";

        public ProductsService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public void SaveProductsToCache(List<Product> products)
        {
            _memoryCache.Set(CacheKey, products, TimeSpan.FromMinutes(30));
        }

        public List<Product> GetAllProductsFromCache()
        {
            if (_memoryCache.TryGetValue(CacheKey, out List<Product>? products))
            {
                return products ?? new List<Product>();
            }

            return new List<Product>();
        }

        public List<Product> GetProductsPaged(int pageIndex, int pageSize)
        {
            var products = GetAllProductsFromCache();

            return products
                .Skip(pageIndex * pageSize)
                .Take(pageSize)
                .ToList();
        }

        public List<Product> FilterProducts(string category, int minYear)
        {
            var products = GetAllProductsFromCache();

            return products
                .Where(p => p.Category.Equals(category, StringComparison.OrdinalIgnoreCase)
                         && p.ReleaseYear >= minYear)
                .ToList();
        }
    }
}
