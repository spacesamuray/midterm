﻿using midterm_api.Models;

namespace midterm_api.Interfaces
{
    public interface IProductService
    {
        void SaveProductsToCache(List<Product> products);
        List<Product> GetAllProductsFromCache();
        List<Product> GetProductsPaged(int pageIndex, int pageSize);
        List<Product> FilterProducts(string category, int minYear);
    }
}
