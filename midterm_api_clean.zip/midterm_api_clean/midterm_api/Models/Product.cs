﻿namespace midterm_api.Models
{
    public class Product
    {
        public string Title { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public int ReleaseYear { get; set; }
        public bool IsAvailable { get; set; }
    }
}
