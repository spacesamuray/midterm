﻿using midterm_api.Models;
using Microsoft.EntityFrameworkCore;

namespace midterm_api.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<DbProduct> Products => Set<DbProduct>();
    }
}

